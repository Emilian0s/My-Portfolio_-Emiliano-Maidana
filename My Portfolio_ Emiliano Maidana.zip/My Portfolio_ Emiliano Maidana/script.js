document.addEventListener("DOMContentLoaded", () => {
  const links = document.querySelectorAll("nav a");
  const sections = document.querySelectorAll("main section");

  // Navegación entre secciones
  links.forEach(link => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      const targetId = link.getAttribute("data-section");

      sections.forEach(section => {
        if (section.id === targetId) {
          section.classList.remove("hidden-section", "exiting-section");
          section.offsetHeight; // Reinicia animación
          section.classList.add("active-section");
          runTypewriterIn(section);
        } else if (section.classList.contains("active-section")) {
          section.classList.remove("active-section");
          section.classList.add("exiting-section");
          section.addEventListener("animationend", () => {
            section.classList.remove("exiting-section");
            section.classList.add("hidden-section");
          }, { once: true });
        }
      });
    });
  });

  // Cambio de nombre al pasar el mouse
  const name = document.getElementById("name");
  if (name) {
    const originalText = name.textContent;
    const hoverText = "FullStack Developer";

    name.addEventListener("mouseenter", () => {
      name.textContent = hoverText;
      name.classList.add("name-hover");
    });

    name.addEventListener("mouseleave", () => {
      name.textContent = originalText;
      name.classList.remove("name-hover");
    });
  }

  // Mostrar última actualización
  const lastUpdated = document.getElementById("last-updated");
  if (lastUpdated) {
    const fecha = new Date(document.lastModified);
    const options = { year: "numeric", month: "long", day: "numeric" };
    lastUpdated.textContent = `Last updated: ${fecha.toLocaleDateString("en-US", options)}`;
  }

  // Máquina de escribir para párrafos que ya están visibles en la carga
  const initialSection = document.querySelector("main section.active-section");
  if (initialSection) {
    runTypewriterIn(initialSection);
  }

  // Carrusel
  window.scrollCarousel = function(direction) {
    const track = document.getElementById("carouselTrack");
    const scrollAmount = 300;
    if (direction === "left") {
      track.scrollBy({ left: -scrollAmount, behavior: "smooth" });
    } else {
      track.scrollBy({ left: scrollAmount, behavior: "smooth" });
    }
  };

  // Activar función secreta con doble click combinado
  let leftPressed = false;
  let rightPressed = false;
  let comboClickCount = 0;
  let comboTimer = null;
  let specialFunctionActive = false;

  document.addEventListener("mousedown", (e) => {
    if (e.button === 0) leftPressed = true;
    if (e.button === 2) rightPressed = true;

    if (leftPressed && rightPressed) {
      comboClickCount++;

      if (comboClickCount === 2) {
        toggleSpecialFunction();
        resetCombo();
      } else {
        clearTimeout(comboTimer);
        comboTimer = setTimeout(() => {
          resetCombo();
        }, 1000);
      }
    }
  });

  document.addEventListener("mouseup", (e) => {
    if (e.button === 0) leftPressed = false;
    if (e.button === 2) rightPressed = false;
  });

  document.addEventListener("contextmenu", (e) => {
    e.preventDefault();
  });

  function resetCombo() {
    comboClickCount = 0;
    leftPressed = false;
    rightPressed = false;
  }

  function toggleSpecialFunction() {
    specialFunctionActive = !specialFunctionActive;

    if (specialFunctionActive) {
      activateSpecialFunction();
    } else {
      deactivateSpecialFunction();
    }
  }

  function activateSpecialFunction() {
    alert("Special mode ACTIVATED!");
    // Por ejemplo: document.body.style.backgroundColor = "#222";
  }

  function deactivateSpecialFunction() {
    alert("Special mode DEACTIVATED!");
    // Por ejemplo: document.body.style.backgroundColor = "#f4f4f4";
  }

});

// Función efecto máquina de escribir con callback
function typeWriterEffect(element, speed = 20, callback = null) {
  const text = element.textContent;
  element.textContent = "";
  let index = 0;

  function type() {
    if (index < text.length) {
      element.textContent += text.charAt(index);
      index++;
      setTimeout(type, speed);
    } else if (callback) {
      callback(); // Llama al siguiente
    }
  }

  type();
}

// Función para ejecutar efecto en todos los h2, p y li en cascada
function runTypewriterIn(section) {
  const elements = section.querySelectorAll("h2.typewriter, p.typewriter, li.typewriter");
  
  // Ocultar todo al inicio
  elements.forEach(el => {
    el.style.visibility = "hidden";
  });

  let current = 0;

  function showNext() {
    if (current < elements.length) {
      const el = elements[current];
      el.style.visibility = "visible";
      typeWriterEffect(el, 20, showNext);
      current++;
    }
  }

  showNext();
}